---
title: About Stanley Text
description: About page.
date: 2025-11-02
lastmod: 2025-11-02
tags: about page
draft: false
pin: 2
---

# About Stanley the Cat


Text about Stanley


