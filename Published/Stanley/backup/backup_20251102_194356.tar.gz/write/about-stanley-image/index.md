---
title: About Stanley with Images
description: An about page testing images.
date: 2025-11-02
pin: 2
---

# About Stanley with Images

Text here.

## Normal Stanley

![Normal Stanley](stanley_250.jpg)

I suspect I can only do one image.

