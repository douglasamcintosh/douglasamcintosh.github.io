---
title: About
description: About this blog.
date: 2025-11-02
lastmod: 2025-11-02
tags: about page
draft: false
pin: 1
---

# Stanley's Fat Cat Chat

![Stanley](image.jpg)

Stanley is a cat who pretends to write a blog. Nothing here should be taken seriously. Nothing here is meant.

Thank you.
