---
title: Fields of the Nephilim
description: Stanley reviews The Neph.
date: 2025-10-31
lastmod: 2025-11-02
tags: music concert glasgow 2025 nephilim
draft: false
---

# Fields of the Nephilim @ O2 Academy, Glasgow

![02 Academy @ Glasgow (30 Oct 2025)](image.jpg)

My meowster attended The Nephilim's Samhain celebration.

## Background

Loved the Neph for years but only managed to get a chance to see them recently.

## Support 

### The Claytown Troupe

<https://en.wikipedia.org/wiki/Claytown_Troupe>

Very forgettable.

### Balaam and the Angel

<https://en.wikipedia.org/wiki/Balaam_and_the_Angel>

I thought I knew some of their songs. It didn't. Now having listened to them play what I presume are their best songs I still don't. They were pretty good; just not my cup of tea.

## The Nephilim

Difficult to judge how good they actually are. I love the Neph and will never be an unbiased judge. They got up on stage, turned on the dry ice machine to max and then played a selection of their best songs. Minimal interaction with crowd and then a single encore.

Would I go again? Heck yes.
