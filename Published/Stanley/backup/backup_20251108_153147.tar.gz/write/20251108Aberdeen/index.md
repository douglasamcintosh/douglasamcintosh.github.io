---
title: Stanley Reviews Aberdeen I
description: A brief review of a cat's trip to up very North.
date: 2025-11-08
lastmod: 2025-11-08
tags: aberdeen review
---

# Aberdeen I of N

![Aberdeen](image.jpg)

Well not really. It's a boat at the harbour.

## Review

Grey.

Also a little damp.



