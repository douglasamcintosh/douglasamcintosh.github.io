---
title: South East Asian Rock and Metal Playlist
description: Probably pushing the accepted definitions of South East Asia, Rock and Metal.
date: 2025-11-08
lastmod: 2025-11-08
tags: music youtube playlist rock metal
---

# South East Asian Rock and Metal Playlist

This was quite difficult to make. There are a lot of different groups and singers that I like. I have aimed for variety.



Playlist Link: <https://www.youtube.com/playlist?list=PLGdExAWayyzLvW_x218Uc0Zdfx-k9tuGZ>

## Babymetal - Megitsune

<https://youtu.be/cK3NMZAUKGw?si=WAppwgW15KGgm4Bo>

Are Babymetal actually metal? Or are they just an idol unit grafted onto some metal music production company. I don't really care. They are metal enough for me.

Recently they been on a tear and doing a bunch of collabs with other bands.

with Tom Morello!

<https://youtu.be/hkij4LvACZ0?si=0sbZTf5FYit_HFqn>

and ElectricCallboy, this one is a bit of a bop. Or possibly a deranged Eurovision entry.

<https://youtu.be/EDnIEWyVIlE?si=N8ns7y-oQQhIg_KN>

Sakura Gakuin were the unit Babymetal were part of before they became Babymetal. Here is an example:

<https://youtu.be/OS190K_H69Q?si=jniTgy2dNwwcud58>

Anyway I love this song and I still play it when I need a boost coming in to work.

## BAND-MAID - Thrill

<https://youtu.be/Uds7g3M-4lQ?si=ns3jjNWKBLzFF3Cw>

They're a rock band who dress as maids. I don't know why.

Here is one of their more recent songs, live:

<https://youtu.be/5I6VV4HYnW8?si=8GZNNLKp---HykbD>

Would I go to see them live? Heck yes.

## 烏牛欄大護法 - 官方MV ft. 何韻詩

( CHTHONIC - Millennia's Faith Undone)

<https://youtu.be/Wil6crOV6DU?si=CLH9mIR-4f_M1emc>

Taiwanese black metal. I have no idea what they are singing about and suspect I don't really want to know. Possibly FFVII summons?

## Synsnake - Saturn In The Loop

<https://youtu.be/Fzkj6ywgjJQ?si=Iy6jOkfoJdABXiZI>

South Korean electronic metalcore. Give it a while to kick in. 

## 롤링쿼츠 - 피어리스

(Rolling Quartz  - Fearless)

<https://youtu.be/5Vp1of6Z0ro?si=Z8Hrr9Q4jNN-q9M2>

3.8 Million views! Though not actually the song I was looking for. I thought they were mor epower metal.

I may have been thinking of this Xena Warrior Princess cosplay:

<https://youtu.be/c9ZqoqCPyd0?si=A-1SZBCB7jTnQzsP>

Who knows?

## マキシマム ザ ホルモン - 予襲復讐

(Maximum the Hormone - Pre-attack Revenge)

<https://youtu.be/beN5ep5MrdY?si=pKcKim8e-PPd00GP>

MTH are huge. Proper Japanese metal.

They did this collab with one of my other favourite bands:

<https://youtu.be/teRgh01Xb1U?si=-c5jgxs3uE9Fddt3>

I'm not quick sure what genre they are, the seem to move between rock, metal, screamo and something else.

Both these songs have about 30M views.

## Bloodywood  - Expect A Riot

<https://youtu.be/Gsy5sJy5_34?si=pJIIZ_kwvDtVl1ue>

Recently did a collab with Babymetal. They seem to be channelling RATM. I'm not really sure how this made it on to my list but too late now.

## NECRONOMIDOL - Ritual

<https://youtu.be/9j7mDS5vn9Y?si=Q6ZVA1AE3fx2gFjX>

I love Necronomidol. Goth Idols! 

Here's a song about death in a toilet:

<https://youtu.be/2kBK33DvIoM?si=V8LI5UILe27KZXW_>

and here is a song about saving the world:

<https://youtu.be/vVacOaFbrdE?si=rBOIgq6ujkvrmn1D>

## Utsu-P - I Thought I Was An Angel

<https://youtu.be/UvUJbhxUKT8?si=LoaNjh9e3suwxXTw>

Utsu-P is one of the heavier vocaloid music producers and this one uses the voice of Hatsune Miku who is the Taylor Swift of computer generated pop stairs (no AI involved)

Miku does a lot of different styles:

<https://youtube.com/playlist?list=PLs5vrZZybIi-AWIAF-Lt-23clxfTzE-1J&si=BbH55of0hCikXh_N>

including Goth:

<https://youtu.be/-_e1NARdYLA?si=4AkAjBmSaBuV0Pwo>

# 花冷え。 - お先に失礼します。

(Hanabie. - (Pardon Me I Have To Go Now))

<https://youtu.be/fuFbQ-Mewfw?si=holP1w-nuEKecqar>

This is who I went to see in Glasgow recently. Every song a banger.

Here's one of their newer songs that goes even harder:

https://youtu.be/dcKxYScvUsU?si=CVIiunZEr7SUw-kf


# Honourable Mentions

## Survive Said The Prophet - MUKANJYO

<https://youtu.be/teRgh01Xb1U?si=-c5jgxs3uE9Fddt3>

## Haru Circle covers MONO NO AWARE

<https://youtu.be/J76S5q_ETfo?si=SOtopWkyfK_6YNla>

This is not metal at all. It's just here to earworm you.

Original version here: 

<https://youtu.be/w9CvXg4jpZU?si=ti-8-C1tJB2rSwWX>

# Next Time

Next list will be all the random stuff I came across that got stuck in my head.
