---
title: Random Music Playlist
description: Various songs that I came across while working on other playlists. Old faves and new discoveries.
date: 2025-11-15
lastmod: 2025-11-15
tags: music playlist
---

# Pic 'N' Music Mix Playlist

Various bits and bobs that have got stuck in my head while working on other lists. I will try to include a spotify list as well if my account is still working. Some of these bands may be on other playlists.

Youtube Link:

<https://youtube.com/playlist?list=PLGdExAWayyzIfppVxlufxNCEv9YBFrYr8&si=UvMcuCEcJypKMbvo>

Spotify Link:

<https://open.spotify.com/playlist/0J9GNaWpNNM353ORoVGPJC?si=J9ATX-8hRV-T5J3bHxe65A>

## Ado - うっせぇわ (Usseewa)

<https://youtu.be/Qp3b-RXtz4w?si=rlR_qVM7yccD0VLl>

Ado's debut single and attack on Japanese society. Banned in many nurseries because the punk kids were singing the lyrics to their teachers.

Ado did a duet with Hatsune Miku that literally reduced people to tears. 

<https://youtu.be/Vrr2gFTYMGQ>

Ado does not allow any pictures of herself to be taken, this is why she only appears in shadow.

She went on to produce the following act which can be considered a heck you to the Japanese Idol industry

## Phantom Siita - "Just Wanna xxxx With You"

<https://youtu.be/wRQ7TpV0JSA?si=gCj_T64NktovGVjA>

Is this song about kissing or murder? Given the video I suspect the latter.

If you want to see what Phantom Siita are fighting against here is a video by probably the most default idol group

<https://youtu.be/dFf4AgBNR1E>

That piece of mediocrity has 261 million views!

Something a bit more upbeat.

## ATARASHII GAKKO! - Fly High

<https://youtu.be/CIv-d_366z0?si=Y0dYjUKBAWatPABQ>

Are Atarashii Gakko! the best group in the world? I'm not saying they are; I'm not saying they're not.

It's worth it for the video alone. I would also suggest One Heart as a bit of upbeat bop.

<https://youtu.be/Ie90LB-7nkA> or <https://open.spotify.com/track/6ArjJicjIjgcbKOzBtcBkh?si=bf036ec867a34351>

Another anti-idol idol group is Planck Stars who may not sound it but have a punk vibe

<https://youtu.be/J1FgEz9hM2I> or <https://open.spotify.com/track/2lmVe2KmOqvyWoKhL9VzML?si=ed478a1d60ad4646>

They famously had a popularity vote for their fan club. The losing member of the band was going to have to star in an ... JAV video (don't google that at work, also probably Redundant Acronym Syndrome Syndrome alert). 

Moving onto something a bit more wholesome.

## NECRONOMIDOL - santa sangre

<https://youtu.be/2kBK33DvIoM?si=9bkdRqoENKK8btSO>

<https://open.spotify.com/track/2KaerEueW94gQaVuKa9cay?si=f9e318643ff94937>

I think I may have already linked to this song. Is this the only song I have about death in the girl's toilets? No. Is it he only one I'm including on this list? Yes.

Is this a Japanese thing? I don't know. Maybe they stole it from J. K. 'Terf' Rowling

Something more wholesome this time?

## ゆるめるモ！『ゾンビダンス』

You'll Melt More - Zombie Dance

<https://youtu.be/d6ZBdKA5vpE?si=etuOh9pt45KWXNpA>

<https://open.spotify.com/track/27pHxKvBIPlSjSSVEf5c7E?si=c16061197464440b>

This song is not good. YMM are famous (in Japan) for being the band that ano emerged from. 

This song is only on this list as it got stuck in my head when I was looking for inspiration for a RPG scenario I was working on.

Go look here to look at YMM's awesome album covers:

<https://open.spotify.com/track/27pHxKvBIPlSjSSVEf5c7E?si=c16061197464440b>

## Ryokuoushoku Shakai - Be a flower

<https://youtu.be/v-WcMQbXbKY?si=0fK2SOzuCy_nTVwB>

<https://open.spotify.com/track/2EmkTBTh964LQen4Vz0svg?si=3538ee9118004b6b>

This is the theme song from an anime about a clever apothecary who solves mysteries in ancient China with the power of her brain. She's like a Kawaii Sherlock Holmes.

I expected the music video to reference this; it doesn't. I have no idea what is happening here but I love it.

Other anime theme song bangers

<https://youtu.be/M2cckDmNLMI>

<https://youtu.be/tRwHpyOq4P4>

The best anime OP of recent year though is by ...

## YOASOBI - 「アイドル」

<https://youtu.be/ZRtdQ81jPUQ>

<https://open.spotify.com/track/7ovUcF5uHTBRzUpB6ZOmvt?si=d4ed1f122591409c>

Do you like anime? Do you like anime about cute and / or handsome people fufilling their dreams by hard work and the power of friendship?

Then [Oshi no Ko] is probably no tthe anime fo ryou.

This is story about idol fans being reborn as the twin children of their favourite idol who is then brutally murdered in front of them leading to a journey of revenge, betrayal, more murder, psychopomps and boppy idol hits.

Every song by YOASOBI is fabulous. Best concert of the year.

## HANA - ROSE

<https://youtu.be/rGPd0FyjQ9w?si=Z8YiNCsynBNZpWzS>

<https://open.spotify.com/track/5JTNhYqB0eG0ivgZcBviJ0?si=08f000c6a6c9431c>

No idea how this song is on the playlist. Glory to Friend Computer.

Next song.

## プランクスターズ - HE HIS HIM HIS

<https://youtu.be/h2rdFRgvX7g?si=_f7X7SvVZz2loN9z>

<https://open.spotify.com/track/3qX3u9QWZVS661XQjr1DuY?si=06a0fde6af6a457d>

I did put a Planck Stars song on this list. Should have checked it all the way to the end!

By way of apology here is a song by ASP (do not google their name) called 'A Song of Punk'

<https://youtu.be/Mfe2YnWwjYE>

## 春ねむり HARU NEMURI -「愛よりたしかなものなんてない / Trust Nothing but Love」

HARU NEMURI tells us to trust nothing but love. We should listen to her.

<https://youtu.be/AZxP_uVzpjQ?si=q6Z53wVc9bbB1Bor>

<https://open.spotify.com/track/3qHrnrvcw7extihlsCFmSX?si=4e1818aa334247c3>

This is my list hopefully there is at least one song that has brought a little joy.

# Honourable Mentions

These will just be YouTube links

## angela - 「アンダンテに恋をして！」

<https://youtu.be/Nf8Oa-GGTfQ>

A song about running away with the European mannequin of your dreams? Maybe.

Everything looks happy. Apart from the losing heroine.


## ネクライトーキー MV「許せ！服部」

<https://youtu.be/tzz-Tjj4TLQ>

A song about doing pushups and having ninja come out of cupboards and beat you with large rubber ... batons? I don't know.

This song has an even better bassline though and was the op for an anime about having 3-4 girlfriends at once. At one point the MC is taken hostage by one of the girfriend candidates; so a lot to unpack there.

<https://youtu.be/KdrP8A7jz5M>

## ORESKABAND(オレスカバンド) - Hands Up Girls

Can you ever have enough Ska? No.

<https://youtu.be/laNd4aDowfs>

## SABASISTER - My girlfriend is PIZZA OF DEATH

<https://youtu.be/lCIzZsroPn0>

Just watch the video. It will only take a minute (and eleven seconds)

Eleven!

Sorry.

I'm done.



