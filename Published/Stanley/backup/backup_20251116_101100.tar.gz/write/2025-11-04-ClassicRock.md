---
title: Metal and Rock Playlist
description: Stanley reviews a playlist his meowster made for a fellow work serf. 
date: 2025-11-04
lastmod: 2025-11-04
tags: music list youtube 2025
draft: false
---

# Metal and Rock Playlist

<https://www.youtube.com/playlist?list=PLGdExAWayyzK10HD9DY5knFsO6fp668wV>

General playlist made to cover some classic rock and metal. Some songs may be neither rock nor metal. Some might not even be very good.

## Classic Rock: Blue Öyster Cult : (Don't Fear) The Reaper

<https://www.youtube.com/watch?v=Dy4HA3vUv2c&list=PLGdExAWayyzK10HD9DY5knFsO6fp668wV&index=4&pp=gAQBiAQB8AUB>

Why is *Don't Fear* in brackets? No one really knows. Unless you spent 2 minutes searching on the internet.

Hold on 

```
CatGPT: How may I serve you meatbag?

meowster:  Tell me why *Don't Fear* is in brackets in the title of (Don't Fear) the Reaper?

CatGPT: No
```

There you have it.

Tyranny and Mutation https://open.spotify.com/album/23XePU1WsEEnWLLKTCEuc5?si=CxB0kCmqSmWgDRMGupPnhA was my gateway album. 

## King's X - Over My Head

<https://www.youtube.com/watch?v=J2SYPzKzD94&list=PLGdExAWayyzK10HD9DY5knFsO6fp668wV&index=9&pp=gAQBiAQB8AUB>

Absolutely the best rock band to never make it big.

## Ministry - Jesus Built My Hotrod

<https://www.youtube.com/watch?v=GXCh9OhDiCI&list=PLGdExAWayyzK10HD9DY5knFsO6fp668wV&index=6&pp=gAQBiAQB8AUB>

```
CatGPT: What now meatsack?

meowster: Is this song rock or metal?

CatGPT: No
```

I can't really argue with that but this song got me through the early 90s and was my introduction to Industrial Metal. It's probably a metaphor for something.

## Sisters of Mercy - Doctor Jeep

<https://www.youtube.com/watch?v=Ejw-M7CDtkk&list=PLGdExAWayyzK10HD9DY5knFsO6fp668wV&index=2&pp=gAQBiAQB8AUB>

Most disappointing concert I've been to recently. 

The Sisters had three main phases. First and Last and Always (First Album): Miserable. Floodland (Second Album): Bombastic edgelord. Vision Thing (Third Album): Goth Meatloaf.

## Mastodon - High Road

<https://www.youtube.com/watch?v=6Aw1WnNVcYw&list=PLGdExAWayyzK10HD9DY5knFsO6fp668wV&index=10&pp=gAQBiAQB8AUB>

A 2014 song. This might be one of the more modern songs. Mastodon were everywhere for a while. I'm not sure what happened to them. Let's see:

```
CatGPT: Meat?

meowster: Are Mastodon still happening?

CatGPT: The hairy elephants? No. The progressive rock & metal band? Yes.
```

Well who knew?

## Cold in Berlin - God I Love You

<https://www.youtube.com/watch?v=-iTv_InV9nU&list=PLGdExAWayyzK10HD9DY5knFsO6fp668wV&index=1&pp=gAQBiAQB8AUB>

I may have picked the wrong song. I would suggest listening to the following one instead.

<https://www.youtube.com/watch?v=mct0I5QRyjg>

I saw them at the first Edinburgh Goth Festival and they terrified me.

## Gloryhammer - Hootsforce

<https://www.youtube.com/watch?v=BkUAzcja74Y&list=PLGdExAWayyzK10HD9DY5knFsO6fp668wV&index=3>

Progressive power metal with a touch of the symphonic.

A series of concept albums about the evil wizard Zargothrax taking over Dundee with undead Unicorns and invading the Kingdom of Fife.

## MASTER BOOT RECORD - INTERNET PROTOCOL

<https://www.youtube.com/watch?v=t6KFfYdNPh8&list=PLGdExAWayyzK10HD9DY5knFsO6fp668wV&index=5>

A 486SX PC living in a basement churns out tunes for our AI overlords to listen to.

Might be better using this link to listen to an individual song <https://masterbootrecord.bandcamp.com/track/cls-nfo>

## Rammstein - Deutchland

<https://www.youtube.com/watch?v=NeQM1c-XCDc&list=PLGdExAWayyzK10HD9DY5knFsO6fp668wV&index=8>

It's Rammstein.

## Tumor Circus = The Man With Corkscrew Eyes

<https://www.youtube.com/watch?v=fiVd50Y7Qbw&list=PLGdExAWayyzK10HD9DY5knFsO6fp668wV&index=7>

I could explain the era in my life during which I thought this was a good song.

```
CatGPT: 'Sup?

meowster: What was my life like when I thought this was a good song?

CatGPT: Been better.
```

I don't know what that means.

Is it rock or metal? No. Is it Jello Biafra on lyrics? Yes!

# Also Ran

## Lake Malice

Saw them supporting Hanabie and they were amazing.

<https://www.youtube.com/watch?v=W-QSp4NkeoI>

## Lard

The band I was actually thinking of when I added Tumor Circus to the list.

<https://www.youtube.com/watch?v=ZXQ0uMu9YXU>

Next list soon.

