---
title: 2025-11-15 Espirit D'Air @ P J Molloys, Dunfermline
description: Stanley goes to see Espirit D'Air for the third time
date: 2025-11-15
lastmod: 2025-11-15
tags: music concert dunfermline 2025 
---

#  2025-11-15 Espirit D'Air @ P J Molloys, Dunfermline

![Espirit D'Air Making Musical Noises](image.jpg)

[https://www.espritdair.com/](https://www.espritdair.com/)

They've just released Aeons which they describe as a dark future metal odyssey which seems about right.

## History

As a small and somewhat corpulent cat it is an effort to make a long journey from Cat Kingdom but I have made the effort to go see this band three times now. Discovering them by finding Kai playing for the Sisters of Mercy. That was a bad gig, would not recommend, but Kai was a delight.


## Gig

Playing two sets without support they were as always amazing. Excellent crowd work. Good selection of songs and and awesome sound. Slightly let down by some bad mixing for the first set but some knobs had clearly been twiddled by the second set.

Crowd were awesome, most attending very clearly being there for the band and not just for a night out.

A wee joke about Irn-Bru. Everything this cat needs for a good night out.

Stanley; a cat, not a professional gig reviewer.






